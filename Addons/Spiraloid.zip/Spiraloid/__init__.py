# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

bl_info = {
    "name": "Spiraloid",
    "description": "Spiraloid Toolkit",
    "author": "Bay Raitt",
    "version": (0, 0, 1),
    "blender": (3, 1, 0),
    "location": "Spiraloid Menu",
    "wiki_url": "",                
    "tracker_url": "",
    "category": "3D View"}

if "bpy" in locals():
    import importlib
    importlib.reload(Spiraloid)
    importlib.reload(preferences)
else:
    from . import Spiraloid
    from . import preferences

import bpy


def draw_spiraloid_menu(self, context):
    layout = self.layout
    layout.menu(Spiraloid.SPIRALOID_MT_Menu.bl_idname)

def draw_toggle_mods_menu(self, context):
    layout = self.layout
    layout.separator()
    layout.operator(Spiraloid.SPIRALOID_MT_toggle_mods.bl_idname)



classes = (
    Spiraloid.SPIRALOID_MT_Menu,
    Spiraloid.SPIRALOID_MT_SubMenuHelp,
    Spiraloid.SPIRALOID_MT_toggle_mods,
    Spiraloid.SPIRALOID_MT_cycle_visible_next,
    Spiraloid.SPIRALOID_MT_cycle_visible_previous,
    Spiraloid.SPIRALOID_MT_SubMenuUtilities,
    Spiraloid.SPIRALOID_MT_SubMenuMaterials,
    Spiraloid.SPIRALOID_MT_nuke,
    Spiraloid.SPIRALOID_MT_nuke_invert,
    Spiraloid.SPIRALOID_MT_nuke_bsdf_uv_texture,
    Spiraloid.SPIRALOID_MT_nuke_bsdf_triplanar_texture,
    Spiraloid.SPIRALOID_MT_nuke_flat,
    Spiraloid.SPIRALOID_MT_uvmap,
    Spiraloid.SPIRALOID_MT_uvmap_quadrants,
    Spiraloid.SPIRALOID_MT_automesh,
    Spiraloid.SPIRALOID_MT_nuke_flat_vertex_color,
    Spiraloid.SPIRALOID_MT_nuke_flat_texture,
    Spiraloid.SPIRALOID_MT_nuke_diffuse_texture,
    Spiraloid.SPIRALOID_MT__workshop,
    Spiraloid.SPIRALOID_MT_bake_vertex_color,
    Spiraloid.SPIRALOID_MT_add_ao,
    Spiraloid.SPIRALOID_MT_add_curvature,
    Spiraloid.SPIRALOID_MT_add_cavity,
    Spiraloid.SPIRALOID_MT_add_gradient,
    Spiraloid.SPIRALOID_MT_bake_texture_to_vertex_color,
    Spiraloid.SPIRALOID_MT_regenerate_video,
    Spiraloid.SPIRALOID_MT_open_filefolder,
    Spiraloid.SPIRALOID_MT_incremental_save,
    Spiraloid.SPIRALOID_MT_empty_trash,
    preferences.SpiraloidPreferences,
    )


def register():
    for c in classes:
        bpy.utils.register_class(c)

    bpy.types.TOPBAR_MT_editor_menus.append(draw_spiraloid_menu)
    bpy.types.VIEW3D_MT_view.append(draw_toggle_mods_menu) 

def unregister():
    [bpy.utils.unregister_class(c) for c in classes]


    bpy.types.TOPBAR_MT_editor_menus.remove(draw_spiraloid_menu)
    bpy.types.VIEW3D_MT_view.remove(draw_toggle_mods_menu) 