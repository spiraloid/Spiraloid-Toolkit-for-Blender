# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

bl_info = {
    "name": "Spiraloid",
    "description": "Spiraloid Toolkit",
    "author": "Bay Raitt",
    "version": (0, 0, 1),
    "blender": (3, 1, 0),
    "location": "Spiraloid Menu",
    "wiki_url": "",                
    "tracker_url": "",
    "category": "3D View"}

if "bpy" in locals():
    import importlib
    importlib.reload(Spiraloid)
    importlib.reload(preferences)
    importlib.reload(fastpreview)
else:
    from . import Spiraloid
    from . import preferences
    from . import fastpreview

import bpy

#------------------------------------------------------

class SPIRALOID_MT_Menu(bpy.types.Menu):
    bl_idname = "SPIRALOID_MT_Menu"
    bl_label = "Spiraloid"
    
    def draw(self, context):
        layout = self.layout
        layout.operator("wm.spiraloid_nuke")
        layout.operator("wm.spiraloid_nuke_invert")
        # layout.operator("view3d.INFO_HT_spiraloid_color_pallet")

        layout.menu(SPIRALOID_MT_SubMenuMaterials.bl_idname )
        layout.menu(SPIRALOID_MT_SubMenuUtilities.bl_idname )

        layout.separator()

        layout.menu(SPIRALOID_MT_SubMenuWeb.bl_idname, icon="URL")
        layout.separator()
        layout.operator("wm.spiraloid_empty_trash")

class SPIRALOID_MT_SubMenuWeb(bpy.types.Menu):
    bl_idname = 'SPIRALOID_MT_SubMenuWeb'
    bl_label = 'Web'

    def draw(self, context):
        layout = self.layout
        layout.operator("view3d.spiraloid_web_open_kofi")
        # layout.operator("view3d.spiraloid_web_open_github")

class SPIRALOID_MT_SubMenuUtilities(bpy.types.Menu):
    bl_idname = 'SPIRALOID_MT_SubMenuUtilities'
    bl_label = 'Utilities'

    def draw(self, context):
        layout = self.layout
        # layout.operator("view3d.spiraloid_bake_collection")
        layout.operator("view3d.spiraloid_automesh")
        layout.operator("view3d.spiraloid_uvmap")
        layout.operator("view3d.spiraloid_uvmap_quadrants")
        layout.separator()
        layout.operator("wm.spiraloid_cycle_visible_next")
        layout.operator("wm.spiraloid_cycle_visible_previous")
        layout.separator()
        layout.operator("wm.spiraloid_smart_previous_frame")
        layout.operator("wm.spiraloid_smart_next_frame")
        layout.operator("wm.spiraloid_smart_previous_key")
        layout.operator("wm.spiraloid_smart_next_key")
        layout.operator("screen.spiraloid_smart_key")
        layout.operator("wm.spiraloid_smart_clean_key")
        layout.operator("wm.spiraloid_smart_set_preview_range")

        layout.separator()
        layout.operator("view3d.spiraloid_vertex_color_to_texture")
        layout.operator("view3d.spiraloid_texture_to_vertex_color")
        layout.separator()
        layout.operator("view3d.spiraloid_regenerate_scene_strip")
        layout.separator()
        layout.operator("wm.spiraloid_open_filefolder")
        layout.operator("wm.spiraloid_incremental_save")


class SPIRALOID_MT_SubMenuMaterials(bpy.types.Menu):
    bl_idname = 'SPIRALOID_MT_SubMenuMaterials'
    bl_label = 'Materials'

    def draw(self, context):
        layout = self.layout
        layout.operator("view3d.spiraloid_nuke_flat_texture")
        layout.operator("view3d.spiraloid_nuke_diffuse_texture")
        layout.operator("view3d.spiraloid_nuke_bsdf_uv_texture")
        layout.operator("view3d.spiraloid_nuke_bsdf_triplanar_texture")
        layout.separator()
        layout.operator("view3d.spiraloid_nuke_flat")
        layout.separator() 
        layout.operator("view3d.spiraloid_nuke_flat_vertex_color")
        layout.separator()
        layout.operator("object.spiraloid_add_ao")
        layout.operator("view3d.spiraloid_add_curvature")
        layout.operator("view3d.spiraloid_add_cavity")
        layout.operator("object.spiraloid_add_gradient")



def draw_spiraloid_menu(self, context):
    layout = self.layout
    layout.menu(SPIRALOID_MT_Menu.bl_idname)

def draw_toggle_mods_menu(self, context):
    layout = self.layout
    layout.separator()
    layout.operator(Spiraloid.SPIRALOID_MT_toggle_mods.bl_idname)


classes = (
    SPIRALOID_MT_Menu,
    SPIRALOID_MT_SubMenuUtilities,
    SPIRALOID_MT_SubMenuMaterials,
    SPIRALOID_MT_SubMenuWeb,
    Spiraloid.SPIRALOID_MT_web_open_kofi,
    Spiraloid.SPIRALOID_MT_toggle_mods,
    Spiraloid.SPIRALOID_MT_cycle_visible_next,
    Spiraloid.SPIRALOID_MT_cycle_visible_previous,
    Spiraloid.SPIRALOID_MT_nuke,
    Spiraloid.SPIRALOID_MT_nuke_invert,
    Spiraloid.SPIRALOID_MT_nuke_bsdf_uv_texture,
    Spiraloid.SPIRALOID_MT_nuke_bsdf_triplanar_texture,
    Spiraloid.SPIRALOID_MT_nuke_flat,
    Spiraloid.SPIRALOID_MT_uvmap,
    Spiraloid.SPIRALOID_MT_uvmap_quadrants,
    Spiraloid.SPIRALOID_MT_automesh,
    Spiraloid.SPIRALOID_MT_nuke_flat_vertex_color,
    Spiraloid.SPIRALOID_MT_nuke_flat_texture,
    Spiraloid.SPIRALOID_MT_nuke_diffuse_texture,
    Spiraloid.SPIRALOID_MT_bake_vertex_color,
    Spiraloid.SPIRALOID_MT_add_ao,
    Spiraloid.SPIRALOID_MT_add_curvature,
    Spiraloid.SPIRALOID_MT_add_cavity,
    Spiraloid.SPIRALOID_MT_add_gradient,
    Spiraloid.SPIRALOID_MT_bake_texture_to_vertex_color,
    Spiraloid.SPIRALOID_MT_regenerate_video,
    Spiraloid.SPIRALOID_MT_open_filefolder,
    Spiraloid.SPIRALOID_MT_incremental_save,
    Spiraloid.SPIRALOID_MT_empty_trash,
    preferences.SpiraloidPreferences,
    fastpreview.BR_OT_fastpreview,
    fastpreview.BR_OT_smartloop_advance,
    fastpreview.BR_OT_smartloop_regress,
    fastpreview.BR_OT_smartkey,
    fastpreview.BR_OT_smartloop_next_key,
    fastpreview.BR_OT_smartloop_previous_key,
    fastpreview.BR_OT_smart_set_preview_range,
    fastpreview.BR_OT_smartkey_clean,
)

def draw_fast_preview_draw(self, context):
    self.layout.operator(fastpreview.BR_OT_fastpreview.bl_idname, text="Quick Play" )


def register():
    for c in classes:
        bpy.utils.register_class(c)

    bpy.types.TOPBAR_MT_editor_menus.append(draw_spiraloid_menu)
    bpy.types.VIEW3D_MT_view.append(draw_toggle_mods_menu) 
    bpy.types.DOPESHEET_HT_header.append(draw_fast_preview_draw)


def unregister():
    [bpy.utils.unregister_class(c) for c in classes]

    bpy.types.TOPBAR_MT_editor_menus.remove(draw_spiraloid_menu)
    bpy.types.VIEW3D_MT_view.remove(draw_toggle_mods_menu) 
    bpy.types.DOPESHEET_HT_header.remove(draw_fast_preview_draw)
