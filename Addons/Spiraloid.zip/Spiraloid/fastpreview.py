if "bpy" in locals():
    import importlib
    importlib.reload(Spiraloid)
else:
    from . import Spiraloid

import bpy
from mathutils import Vector

bl_info = {    
    'name': 'fastpreview',
    'author': 'Bay Raitt',
    'version': (0, 1),
    'blender': (2, 80, 0),
    'category': 'Animation',
    'location': 'Timeline  > Quick Play Button',
    'description': 'play from first frame, stop returns to current frame',
    'wiki_url': ''}

playing = "False"
brCurframe = 0
brStartRange = 1              
brEndRange = 72


class BR_OT_fastpreview(bpy.types.Operator):
    """play range and return to current frame on stop"""
    bl_idname   = "wm.quick_play"
    bl_label   = "Preview"
    bl_description = "start playback from the first frame"
    def execute(self, context):
        global playing
        if playing == "False":
            global brCurframe                     
            brCurframe = bpy.context.scene.frame_current
            context = bpy.context
            c = context.copy()
            previewStart = bpy.context.scene.frame_start 
            previewEnd = bpy.context.scene.frame_end 

            for i, area in enumerate(context.screen.areas):
                if area.type != 'GRAPH_EDITOR' and area.type != 'DOPESHEET_EDITOR':
                    continue
                # region = area.regions[-1]
                # print("SCREEN:", context.screen.name , "[", i, "]")
                # c["space_data"] = area.spaces.active
                # c["area"] = area
                # c["region"] = region            
                # h = region.height # screen
                # w = region.width  # 
                # bl = region.view2d.region_to_view(0, 0)
                # tr = region.view2d.region_to_view(w, h)
                # previewStart = int(bl[0])
                # previewEnd = int(tr[0])

                is_animated = ""
                try:
                    is_animated = bpy.context.object.animation_data.action
                except:
                    pass
                if is_animated:
                    # for fcu in is_animated.fcurves:
                    #     range = fcu.range()
                    #     action_start = int(range[0])
                    #     action_end = int(range[1])
                    C=bpy.context
                    old_area_type = C.area.type 
                    C.area.type='GRAPH_EDITOR'
                    bpy.ops.graph.previewrange_set()
                    temp_previewStart = bpy.context.scene.frame_preview_start
                    temp_previewEnd = bpy.context.scene.frame_preview_end
                    preview_duration = temp_previewEnd - temp_previewStart 
                    if preview_duration != 0:
                        previewStart =temp_previewStart
                        previewEnd = temp_previewEnd
                    else:
                        previewStart = bpy.context.scene.frame_start  
                        previewEnd =  bpy.context.scene.frame_end 
                    C.area.type=old_area_type
                else:
                    previewStart = bpy.context.scene.frame_start 
                    previewEnd =  bpy.context.scene.frame_end

            bpy.context.scene.use_preview_range = True
            bpy.context.scene.frame_preview_start =  previewStart
            bpy.context.scene.frame_preview_end =  previewEnd
            bpy.context.scene.frame_current = previewStart
            bpy.context.scene.sync_mode = 'NONE'
            
            #bpy.context.scene.frame_current = bpy.context.scene.frame_start            
            bpy.ops.screen.animation_play()

            playing = "True"   
        elif playing == "True":
            brCurframe
            # bpy.context.scene.frame_preview_start =  bpy.context.scene.frame_start
            # bpy.context.scene.frame_preview_end =  bpy.context.scene.frame_end
            bpy.context.scene.use_preview_range = False
            bpy.ops.screen.animation_cancel(restore_frame=False)
            bpy.context.scene.frame_current = brCurframe
            playing = "False"  
          
        return {'FINISHED'}

class BR_OT_smartloop_advance(bpy.types.Operator):
    """frame increment with loop"""
    bl_idname   = "wm.spiraloid_smart_next_frame"
    bl_label   = "smart next frame"
    bl_description = "frame increment with loop"

    def execute(self, context):
        brCurframe = bpy.context.scene.frame_current
        previewStart = bpy.context.scene.frame_preview_start
        previewEnd = bpy.context.scene.frame_preview_end

        if brCurframe == previewEnd:
            bpy.context.scene.frame_current = previewStart
        else:
            bpy.ops.screen.frame_offset(delta=1)
            
        return {'FINISHED'}

class BR_OT_smartloop_regress(bpy.types.Operator):
    """frame decrement with loop"""
    bl_idname   = "wm.spiraloid_smart_previous_frame"
    bl_label   = "smart previous frame"
    bl_description = "frame decrement with loop"

    def execute(self, context):
        brCurframe = bpy.context.scene.frame_current
        previewStart = bpy.context.scene.frame_preview_start
        previewEnd = bpy.context.scene.frame_preview_end
        if brCurframe == previewStart:
            bpy.context.scene.frame_current = previewEnd
        else:
            bpy.ops.screen.frame_offset(delta=-1)
        return {'FINISHED'}


class BR_OT_smartloop_next_key(bpy.types.Operator):
    """frame increment with loop"""
    bl_idname   = "wm.spiraloid_smart_next_key"
    bl_label   = "smart next key"
    bl_description = "keyframe increment with loop"

    def execute(self, context):
        global brCurframe
        starting_mode = bpy.context.object.mode
        previewStart = bpy.context.scene.frame_preview_start
        previewEnd = bpy.context.scene.frame_preview_end

        if brCurframe == previewEnd:
            bpy.context.scene.frame_current = previewStart
        else:
            bpy.ops.screen.keyframe_jump(next=True)

        brCurframe = bpy.context.scene.frame_current
        if "EDIT" in starting_mode:
            bpy.ops.object.mode_set(mode='OBJECT')
            obs = bpy.context.selected_objects
            bpy.ops.object.select_all(action='DESELECT')
            for ob in obs:
                ob.select_set(state=True)
                bpy.context.view_layer.objects.active = ob

        if bpy.context.selected_objects:
            is_animated = ""
            try:
                is_animated = bpy.context.object.animation_data.action
            except:
                pass

            if is_animated is not None:
                C=bpy.context
                old_area_type = C.area.type 
                C.area.type='GRAPH_EDITOR'
                try:
                    # bpy.ops.graph.select_all(action='DESELECT')
                    bpy.ops.graph.select_less()
                    bpy.ops.graph.select_less()
                    bpy.ops.graph.select_less()
                    bpy.ops.graph.select_column(mode='CFRA')
                except:
                    pass
                C.area.type=old_area_type

            bpy.ops.object.mode_set(mode=starting_mode)


        return {'FINISHED'}

class BR_OT_smartloop_previous_key(bpy.types.Operator):
    """frame decrement with loop"""
    bl_idname   = "wm.spiraloid_smart_previous_key"
    bl_label   = "smart previous key"
    bl_description = "keyframe decrement with loop"

    def execute(self, context):
        global brCurframe
        starting_mode = bpy.context.object.mode
        previewStart = bpy.context.scene.frame_preview_start
        previewEnd = bpy.context.scene.frame_preview_end
        if brCurframe == previewStart:
            bpy.context.scene.frame_current = previewEnd
        else:
            bpy.ops.screen.keyframe_jump(next=False)

        brCurframe = bpy.context.scene.frame_current
        if "EDIT" in starting_mode:
            bpy.ops.object.mode_set(mode='OBJECT')
            obs = bpy.context.selected_objects
            bpy.ops.object.select_all(action='DESELECT')
            for ob in obs:
                ob.select_set(state=True)
                bpy.context.view_layer.objects.active = ob


        if bpy.context.selected_objects:
            is_animated = ""
            try:
                is_animated = bpy.context.object.animation_data.action
            except:
                pass
            if is_animated is not None:
                C=bpy.context
                old_area_type = C.area.type 
                C.area.type='GRAPH_EDITOR'
                try:
                    # bpy.ops.graph.select_all(action='DESELECT')
                    bpy.ops.graph.select_less()
                    bpy.ops.graph.select_less()
                    bpy.ops.graph.select_less()
                    bpy.ops.graph.select_column(mode='CFRA')
                except:
                    pass
                C.area.type=old_area_type
            bpy.ops.object.mode_set(mode=starting_mode)
        return {'FINISHED'}


class BR_OT_smart_set_preview_range(bpy.types.Operator):
    """set preview range"""
    bl_idname   = "wm.spiraloid_smart_set_preview_range"
    bl_label   = "smart set preview"
    bl_description = "set preview range"

    def execute(self, context):
        brCurframe = bpy.context.scene.frame_current
        context = bpy.context
        c = context.copy()
        previewStart = bpy.context.scene.frame_start 
        previewEnd = bpy.context.scene.frame_end 

        # for i, area in enumerate(context.screen.areas):
        #     if area.type != 'GRAPH_EDITOR' and area.type != 'DOPESHEET_EDITOR':
        #         continue
        #     region = area.regions[-1]
        #     print("SCREEN:", context.screen.name , "[", i, "]")
        #     c["space_data"] = area.spaces.active
        #     c["area"] = area
        #     c["region"] = region            
        #     h = region.height # screen
        #     w = region.width  # 
        #     bl = region.view2d.region_to_view(0, 0)
        #     tr = region.view2d.region_to_view(w, h)
        #     previewStart = int(bl[0])
        #     previewEnd = int(tr[0])
        # bpy.context.scene.frame_preview_start =  previewStart
        # bpy.context.scene.frame_preview_end =  previewEnd

        C=bpy.context
        old_area_type = C.area.type 
        C.area.type='DOPESHEET_EDITOR'
        if bpy.context.selected_objects:
            bpy.context.scene.use_preview_range = True
            bpy.ops.action.previewrange_set()
            bpy.ops.action.view_selected()
        else:
            # bpy.context.scene.use_preview_range = False
            # bpy.ops.action.previewrange_clear()
            bpy.context.scene.frame_preview_start =  previewStart
            bpy.context.scene.frame_preview_end =  previewEnd
        C.area.type=old_area_type



        return {'FINISHED'}

class BR_OT_smartkey_clean(bpy.types.Operator):
    """clean keyframes"""
    bl_idname   = "wm.spiraloid_smart_clean_key"
    bl_label   = "smart keyframe clear"
    bl_description = "clean keyframes"

    def execute(self, context):
        if bpy.context.mode == 'POSE':
            for bone in bpy.context.selected_pose_bones:
                bone.id_data.animation_data_clear()

        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

        return {'FINISHED'}



class BR_OT_smartkey(bpy.types.Operator):
    """insert smartkey"""
    bl_idname   = "screen.spiraloid_smart_key"
    bl_label   = "smart keyframe"
    bl_description = "smart keyframe"

    def execute(self, context):
        global brCurframe                     
        brCurframe = bpy.context.scene.frame_current
        if bpy.context.mode == 'OBJECT':
            if bpy.context.selected_objects:
                for obj in bpy.context.selected_objects:
                    bpy.ops.object.select_all(action='DESELECT')
                    obj.select_set(state=True)
                    bpy.context.view_layer.objects.active = obj

                    is_animated = ""
                    try:
                        is_animated = obj.animation_data
                    except:
                        pass
                    if is_animated is None:
                        bpy.ops.anim.keyframe_insert(type='LocRotScale')
                    else:
                        bpy.ops.anim.keyframe_insert()


                    # bpy.context.scene.keying_sets_all['Available']
            else:
                bpy.ops.anim.keyframe_insert(type='Default')

        if bpy.context.mode == 'POSE':
            for bone in bpy.context.selected_pose_bones:
                if bone.rotation_mode == 'QUATERNION':
                    is_animated = ""
                    try:
                        is_animated = bone.animation_data
                    except:
                        pass

                    if is_animated is not None:
                        bone.keyframe_insert(data_path="rotation_quaternion")
                    else:
                        bone.rotation_mode = 'XYZ'
                        bone.keyframe_insert(data_path="rotation_euler")

                if bone.rotation_mode == 'XYZ':
                    bone.keyframe_insert(data_path="rotation_euler")

                if not bone.parent:
                    bone.keyframe_insert(data_path="location")
                    


        for key in bpy.context.scene.keying_sets_all:
            if key.bl_label == 'Available':
                 bpy.context.scene.keying_sets.active = key

        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


        autokey_toggle = bpy.context.scene.tool_settings.use_keyframe_insert_auto
        bpy.context.scene.tool_settings.use_keyframe_insert_auto = not autokey_toggle
        # bpy.ops.anim.keying_set_active_set(type='LocRotScale')

        return {'FINISHED'}



# def menu_draw(self, context):
#     self.layout.operator(BR_OT_fastpreview.bl_idname, text="Quick Play" )

# def register():
#     from bpy.utils import register_class
#     register_class(BR_OT_fastpreview)
#     register_class(BR_OT_smart_frame_increment)
#     bpy.types.DOPESHEET_HT_header.append(menu_draw)

# def unregister():
#     from bpy.utils import unregister_class
#     unregister_class(BR_OT_fastpreview)
#     bpy.types.DOPESHEET_HT_header.remove(menu_draw)

#     if __name__ != "__main__":
#         bpy.types.DOPESHEET_HT_header.remove(menu_draw)
                
# if __name__ == "__main__":
#     register()
